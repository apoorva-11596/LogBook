#config file containing credentials for RDS MySQL instance
db_username = "boomerang"
db_password = "B00m3rang"
db_name = "BoomerangServer"
